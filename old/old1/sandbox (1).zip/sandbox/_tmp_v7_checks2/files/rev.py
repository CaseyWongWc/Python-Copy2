print("R")
