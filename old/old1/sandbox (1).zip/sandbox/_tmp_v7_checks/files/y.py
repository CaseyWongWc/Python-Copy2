print("q")
